ABYAN CELL NDESO - Digiflazz Store
Markup: Rp 2000

1. Upload folder ini ke Netlify
2. Site settings > Environment variables:
   DIGIFLAZZ_USERNAME = username_kamu
   DIGIFLAZZ_API_KEY = api_key_kamu
3. Edit index.html untuk ganti nomor WhatsApp di STORE_CONFIG
